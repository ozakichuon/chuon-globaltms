import { Badge } from "@/components/Badge";
import { MiniAvatar } from "@/components/Avatar";
import {
  excelAssignments,
  excelDormitories,
  excelRooms,
} from "@/lib/excel-data";
import Link from "next/link";
import { Home, MapPin } from "lucide-react";

export const dynamic = "force-dynamic";

export default function DormitoriesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Home size={22} /> 寮管理
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          9寮・{excelRooms.length} 部屋・{excelAssignments.length} 入居者
        </p>
      </div>

      <div className="grid gap-4">
        {excelDormitories.map((d) => {
          const rooms = excelRooms.filter((r) => r.dormitory_id === d.id);
          const assigns = excelAssignments.filter((a) => a.dormitory_id === d.id);
          const natCounts: Record<string, number> = {};
          assigns.forEach((a) => {
            const k = a.nationality ?? "不明";
            natCounts[k] = (natCounts[k] ?? 0) + 1;
          });
          const totalRent = assigns.reduce((s, a) => s + (a.rent_burden ?? 0), 0);

          return (
            <div key={d.id} className="card">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                  <h2 className="font-bold text-lg">{d.name}</h2>
                  <div className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                    <MapPin size={12} /> {d.address}
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="text-right">
                    <div className="text-xs text-slate-500">部屋</div>
                    <div className="font-bold">{rooms.length}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">入居</div>
                    <div className="font-bold">{assigns.length}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">家賃合計</div>
                    <div className="font-bold">
                      ¥{totalRent.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* 国籍内訳 */}
              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                {Object.entries(natCounts).map(([k, v]) => (
                  <Badge
                    key={k}
                    className="bg-slate-100 text-slate-700 border border-slate-200"
                  >
                    {k} {v}名
                  </Badge>
                ))}
              </div>

              {/* 部屋別 */}
              <div className="mt-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                {rooms.map((r) => {
                  const residents = assigns.filter((a) => a.room_id === r.id);
                  return (
                    <div
                      key={r.id}
                      className="border border-slate-200 rounded-lg p-2 text-xs"
                    >
                      <div className="font-semibold text-slate-700">
                        {r.room_no ?? r.room_type_label ?? "—"}
                      </div>
                      <div className="mt-1.5 space-y-1">
                        {residents.length === 0 ? (
                          <div className="text-slate-400">空室</div>
                        ) : (
                          residents.map((a) => (
                            <div key={a.id} className="flex items-center gap-1.5">
                              <MiniAvatar
                                name={a.resident_name}
                                nationality={a.nationality}
                                size={22}
                              />
                              {a.employee_id ? (
                                <Link
                                  href={`/employees/${a.employee_id}`}
                                  className="hover:text-brand-600 truncate flex-1"
                                >
                                  {a.resident_name}
                                </Link>
                              ) : (
                                <span className="truncate flex-1">{a.resident_name}</span>
                              )}
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
